package im.zego.mixer.ui;

public interface IMixerStreamUpdateHandler {
    public void onRoomStreamUpdate();
}

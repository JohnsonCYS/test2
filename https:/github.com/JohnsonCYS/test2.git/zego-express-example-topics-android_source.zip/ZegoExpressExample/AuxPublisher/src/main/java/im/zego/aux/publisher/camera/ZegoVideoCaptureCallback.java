package im.zego.aux.publisher.camera;

import android.view.View;

import im.zego.zegoexpress.callback.IZegoCustomVideoCaptureHandler;
import im.zego.zegoexpress.constants.ZegoPublishChannel;


public class ZegoVideoCaptureCallback extends IZegoCustomVideoCaptureHandler {


    public void onStart(ZegoPublishChannel channel) {
    }

    public void onStop(ZegoPublishChannel channel) {
    }

    public void setView(View view){

    }
}

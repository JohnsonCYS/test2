package im.zego.common;

/**
 * Created by zego on 2018/11/15.
 */

public class GetAppIDConfig {

    /**
     * 请提前在即构管理控制台获取 appID 与 appSign
     *  AppID 填写样式示例：
            public static final long appId = 123456789L;
     *  appSign 填写样式示例：
            public static final byte[] appSign = {
                (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
                (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
                (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
                (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
                (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
                (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
                (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
                (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00
            }
     *
     */

    public static final long appId = ;

    public static final byte[] appSign = ;
}